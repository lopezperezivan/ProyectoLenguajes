document.addEventListener('DOMContentLoaded', function() {
    // Función para mostrar mensaje de éxito
    function showSuccessMessage(message) {
        const successMessage = document.getElementById('success-message');
        successMessage.innerText = message;
        successMessage.style.display = 'block';
        setTimeout(function() {
            successMessage.style.display = 'none';
        }, 3000); // Ocultar el mensaje después de 3 segundos
    }

    // Función para mostrar mensaje de error
    function showErrorMessage(message) {
        const errorMessage = document.getElementById('error-message');
        errorMessage.innerText = message;
        errorMessage.style.display = 'block';
        setTimeout(function() {
            errorMessage.style.display = 'none';
        }, 3000); // Ocultar el mensaje después de 3 segundos
    }

    // Obtener el formulario de búsqueda y agregar un listener para el evento submit
    const searchForm = document.getElementById('search-form');
    searchForm.addEventListener('submit', function(event) {
        event.preventDefault(); // Prevenir el envío del formulario por defecto

        const searchInput = document.getElementById('search-input').value.trim().toLowerCase();
        
        // Simular resultados de búsqueda
        if (searchInput !== '') {
            switch (searchInput) {
                case 'inicio':
                    window.location.href = 'index.html';
                    break;
                case 'galería':
                    window.location.href = 'gallery.html';
                    break;
                case 'conóceme':
                    window.location.href = 'aboutme.html';
                    break;
                case 'contacto':
                    window.location.href = 'contact.html';
                    break;
                default:
                    showErrorMessage('No se encontraron resultados para "' + searchInput + '".');
                    break;
            }
        } else {
            showErrorMessage('Por favor, ingrese un término de búsqueda.');
        }
    });

    // Obtener el formulario de contacto y agregar un listener para el evento submit
    const form = document.getElementById('contact-form');
    form.addEventListener('submit', function(event) {
        event.preventDefault(); // Prevenir el envío del formulario por defecto

        // Simular éxito o error aleatoriamente
        const random = Math.random();
        if (random < 0.5) {
            showSuccessMessage('Mensaje enviado con éxito.');
        } else {
            showErrorMessage('Hubo un error al enviar el mensaje.');
        }
    });
});
